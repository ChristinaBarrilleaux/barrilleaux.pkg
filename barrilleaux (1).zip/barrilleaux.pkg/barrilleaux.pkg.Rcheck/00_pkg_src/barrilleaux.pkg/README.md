# barrilleaux.pkg

## An R package for processing crabs data

This R package is used to analysis a crabs data frame to visualize and evaluate color, size, location, and other characteristics of crabs caught in a crabbing contest.

This package can be used to plot, compare, and perform statistical analysis for the crabs data set. This package provides the tools to make connections between characteristics of crabs and to make conclusions about location, species and physical characteristics of the caught crabs.git

Required packages for this package to work are tidyverse and ggplot2.

## Included functions are:

clean

crab_plot

crabs_xysl

lat_chr

lm_fun
